#ifndef ABS_H
#define ABS_H
#define ABS(a) (((a) < 0) ? (-(a)) : (a))
#endif
