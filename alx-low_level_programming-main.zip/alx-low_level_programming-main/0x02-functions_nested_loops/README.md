16.Write a program that finds and prints the first 98 Fibonacci numbers, starting with 1 and 2, followed by a new line. 




