#include "main.h"


/**
 * add - add two ints
 * @a: first int to add
 * @b: second int to add
 * Return: sum of both ints
 **/

int add(int a, int b)
{
	return (a + b);
}
