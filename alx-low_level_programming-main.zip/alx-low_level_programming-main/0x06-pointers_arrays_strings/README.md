Write a function that concatenates two strings.
