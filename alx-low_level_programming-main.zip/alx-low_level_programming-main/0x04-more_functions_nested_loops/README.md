<<<<<<< HEAD
Write a function that checks for uppercase character.
=======
0.Write a function that checks for uppercase character.


>>>>>>> fbbafcbabff7602e60c653ab5ed064dc1395188f
