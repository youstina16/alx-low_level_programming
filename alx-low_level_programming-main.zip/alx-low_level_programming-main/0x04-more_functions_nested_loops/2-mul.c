#include "main.h"


/**
 * mul - multiply
 * @a: first int
 * @b: second int
 * Return: product of both ints
 **/

int mul(int a, int b)
{
	return (a * b);
}
