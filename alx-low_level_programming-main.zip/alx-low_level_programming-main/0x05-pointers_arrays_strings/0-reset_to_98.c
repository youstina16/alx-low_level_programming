#include "main.h"

/**
 * reset_to_98 - set value of int to 98
 * @n: address of value to change
 * Description: resets *n to 98
 * Return: nothing
 **/

void reset_to_98(int *n)
{
	*n = 98;
}
