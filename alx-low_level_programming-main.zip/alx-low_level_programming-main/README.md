Array and strings 
