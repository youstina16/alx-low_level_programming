0x0A. C - argc, argv
