arrays and strings question 7
