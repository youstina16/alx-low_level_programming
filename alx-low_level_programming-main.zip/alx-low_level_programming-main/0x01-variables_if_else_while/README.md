virables and loops
