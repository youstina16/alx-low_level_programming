my first debugging 
